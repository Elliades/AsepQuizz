/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#6366f1',
          dark: '#4f46e5',
        },
        background: {
          DEFAULT: '#111827',
          light: '#1f2937',
        }
      },
    },
  },
  plugins: [
    require('tailwind-scrollbar'),
  ],
} 